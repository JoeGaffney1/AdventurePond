Thank you for supporting Polyplant3D!

You can use this 3D model for your projects. It is just not allowed to sell them.
If you have problems converting the fbx-file to an other popular 3D format, do not hesitate to contact me.

3D Model: 	Dennis Haase
Image source: 	Laszlo Ilyes
